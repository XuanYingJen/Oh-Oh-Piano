#pragma once
#include<iostream>
#include<Windows.h>
using namespace std;
#define SPEED 0.5
#define BORDER 10

void gotoxy(double x, double y) // allows to move inside the terminal using coordinates 
{   // the type is double, so objects can move less than 1 unit 
	HANDLE hCon = GetStdHandle(STD_OUTPUT_HANDLE);
	COORD dwPos;
	dwPos.X = x; // start from 0
	dwPos.Y = y; // start from 0
	SetConsoleCursorPosition(hCon, dwPos);
}

class Drop
{
public:
	explicit Drop(double, double);
	void move();
	void draw();
	void erase();
	bool isout();
	double getX();
	double getY();
private:
	double x;
	double y;
};
Drop::Drop(double X,double Y)
{
	x = X;
	y = Y;
}
void Drop::move()
{
	if (y > 19)
	{
		erase();
		return;
	}
	erase();
	y = y + SPEED;
	draw();
}
void Drop::erase()
{
	gotoxy(x, y); cout << "     ";
}
void Drop::draw()
{
	if (y < 0)
		return;
	gotoxy(x, y); cout << "-----";
}
bool Drop::isout()
{
	if (y > BORDER)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}
double Drop::getX()
{
	return x;
}
double Drop::getY()
{
	return y;
}