#pragma once
#include<iostream>
#include<stdio.h>
#include<conio.h>
#include"drop.h"
#include<windows.h>
#define BORDER_DOWN 28
#define BORDER_RIGHT_WIDE 115
using namespace std;

void DrawWhiteSpace(int a_x, int a_y, int b_x, int b_y) 
{
	for (int i = a_x; i <= b_x; i++)
	{
		for (int j = a_y; j <= b_y; j++)
		{
			gotoxy(i, j);
			cout << " ";
		}
	}
}
bool enter_space() {
	if (_getch() == ' ') {
		return 1;
	}
	else 
		return enter_space();
}
class display {
public:
	void welcomeMessage() {
		DrawWhiteSpace(0, 0, BORDER_RIGHT_WIDE, BORDER_DOWN);
		int x = 7;
		int y = 10;
		gotoxy(x, y); cout << "  _______    _                 _______    _                 ________                           ";
		gotoxy(x, y + 1); cout << " |  ___  |  | |               |  ___  |  | |               |  ____  |                          ";
		gotoxy(x, y + 2); cout << " | |   | |  | |               | |   | |  | |               | |____| |   _     _______       _         _______ ";
		gotoxy(x, y + 3); cout << " | |   | |  | |____           | |   | |  | |____           |  ______|  |_|   /  __   \\     | |____   |  ___  |  ";
		gotoxy(x, y + 4); cout << " | |   | |  |  __  |          | |   | |  |  __  |          | |          _    | |  |   \\    |  __  |  | |   | |";
		gotoxy(x, y + 5); cout << " | |___| |  | |  | |          | |___| |  | |  | |          | |         | |   | |__| |\\ \\   | |  | |  | |___| |";
		gotoxy(x, y + 6); cout << " |_______|  |_|  |_|          |_______|  |_|  |_|          |_|         |_|   \\______/ \\_\\  |_|  |_|  |_______|";
		x = x + 40;
		gotoxy(x, y + 9); cout << "Press 'SPACE' to continue. . .";
		if (enter_space() == 1) {
			system("cls");
		}
	}
	void chooseSong() {
		int x = 30;
		int y = 10;
		gotoxy(x, y); cout << "P r e s s   1 , 2 , 3   t o   c h o o s e   a   s o n g   a n d   e n t e r   i t :";
		gotoxy(x, y + 2); cout << "1.�p�P�P";
		gotoxy(x, y + 4); cout << "2.�q�д���";
		gotoxy(x + 8, y + 8); cout << "#"; cin >> option; getchar();
		if (option == '1') {
			system("cls");
		}
		else if (option == '2') {
			system("cls");
		}
		else {
			system("cls");
			chooseSong();
		}
	}
	void rule() {
		int x = 30;
		int y = 10;
		gotoxy(x, y); cout << "�� :";
		gotoxy(x, y + 2); cout << "���@�ѡA�@�s�����j�Ǹ�u�t�G�~�Ū��P�ǭפF�@��W�s�u����ɦV�{���]�p�v���ҡA";
		gotoxy(x, y + 3); cout << "�b�g�L�@�Ǵ�����A�L�̱N��Ǵ��Ǩ쪺�F��i�{�X�ӡA�éR�W���uOh Oh Piano�v�C";
		gotoxy(x, y + 7); cout << "�C �� �W �h : ";
		gotoxy(x, y + 9); cout << "�Х�'Q'�B'W'�B'E'�B'R'�����C���Agreat��2���Bgood��1���Bbad�h��0��...";
		gotoxy(x+10, y + 12); cout << "Press 'SPACE' to continue. . .";
		if (enter_space() == 1) {
			system("cls");
		}
	}
	bool play_again() {
		int x = 30, y = 15;
		gotoxy(x, y); cout << "Do you want to play again ?";
		gotoxy(x, y + 1); cout << "y) Yes";
		gotoxy(x, y + 2); cout << "n) No";
		while (1) {
			if (_getch() == 'y') {
				system("cls");
				return 1;
			}
			else if (_getch() == 'n') {
				system("cls");
				return 0;
			}
		}
	}
	void game_over() {
		int x = 7;
		int y = 10;
		gotoxy(x, y); cout << "   _________                    ___      ___     _______";
		gotoxy(x, y + 1); cout << "  |  _______|        /\\        |   \\    /   |   |  _____|";
		gotoxy(x, y + 2); cout << "  | |               /  \\       | |\\ \\  / /| |   | |";
		gotoxy(x, y + 3); cout << "  | |   ____       / /\\ \\      | | \\ \\/ / | |   | |_____";
		gotoxy(x, y + 4); cout << "  | |  |__  |     / /__\\ \\     | |  \\__/  | |   |  _____|";
		gotoxy(x, y + 5); cout << "  | |_____| |    / ______ \\    | |        | |   | |_____";
		gotoxy(x, y + 6); cout << "  |_________|   /_/      \\_\\   |_|        |_|   |_______|";
		gotoxy(x + 45, y + 10); cout << "   _________     _          _     _______     ________";
		gotoxy(x + 45, y + 11); cout << "  |  _____  |   \\ \\        / /   |  _____|   |  ____  |";
		gotoxy(x + 45, y + 12); cout << "  | |     | |    \\ \\      / /    | |         | |____| |";
		gotoxy(x + 45, y + 13); cout << "  | |     | |     \\ \\    / /     | |_____    |  __  __|";
		gotoxy(x + 45, y + 14); cout << "  | |     | |      \\ \\  / /      |  _____|   | |  \\ \\";
		gotoxy(x + 45, y + 15); cout << "  | |_____| |       \\ \\/ /       | |_____    | |   \\ \\";
		gotoxy(x + 45, y + 16); cout << "  |_________|        \\__/        |_______|   |_|    \\_\\    ";
	}
private:
	int x;
	int y;
	char option;
};