#pragma once
#include<Windows.h>
#include"drop.h"
using namespace std;
class Line 
{
public:
	explicit Line();
	int getscore();
	void get_score(double,double);
private:
	int score;
};
Line::Line()
{
	score = 0;
	gotoxy(0, 20); cout << "xxxxxxxxxxxxxxxxxxxx";
}
void Line::get_score(double x,double y)
{
	if (y < 21&&y>19)
	{
		score += 2;
		gotoxy(x, 21);
		cout << "great";
	}
	else if (y <= 22 && y >= 18)
	{
		score += 1;
		gotoxy(x, 21);
		cout << "good!";
	}
	else
	{
		gotoxy(x, 21);
		cout << " bad ";
	}
}
int Line::getscore()
{
	return score;
}
