#include"drop.h"
#include<list>
#include<ctime>
#include<windows.h>
#include<mmsystem.h>
#include <iomanip>
#include"display.h"
#include"Line.h"
#pragma comment(lib, "WINMM.LIB")
#pragma warning (disable:4996)

int music_key[42] = { 1,1,2,2,3,3,4,4,4,3,3,2,2,1,4,4,3,3,2,2,1,4,4,3,3,2,2,1,1,1,2,2,3,3,4,4,4,3,3,2,2,1 };
int music_time[42] = { 0,-1,-2,-3,-4,-5,-6,-8,-9,-10,-11,-12,-13,-14,-16,-17,-18,-19,-20,-21,-22,-24,-25,-26,-27,-28,-29,-30,-32,-33,-34,-35,-36,-37,-38,-40,-41,-42,-43,-44,-45,-46 };
using namespace std;
time_t start, t;
double record_time();
void startGame();
int main()
{
	mciSendString(TEXT("open �p�P�P.mp3 alias mysong"), NULL, 0, NULL);

	display p1;
	p1.welcomeMessage();
	p1.rule();
	bool n = 1;
	while (n == 1) {
		p1.chooseSong();
		startGame();
		n = p1.play_again();
	}
	p1.game_over();
	system("pause");
	return 0;
}

void startGame()
{
	Line line;
	list<Drop> drops;
	list<Drop>::iterator d;
	for (int i = 0; i < 42; i++)
	{
		drops.push_back(Drop((music_key[i] - 1) * 5, music_time[i] + 3));
	}
	gotoxy(30, 10); cout << "Score : " << line.getscore();
	int drop = 42;
	mciSendString(TEXT("play mysong"), NULL, 0, NULL);
	while (drop != 0)
	{
		if (1)
		{
			for (d = drops.begin(); d != drops.end(); d++)
			{
				if (d->getY() >= 22)
				{
					d = drops.erase(d);
					drop--;
				}
				d->move();
			}
			Sleep(192);
		}
		if (kbhit())
		{
			gotoxy(0, 21); cout << "                     ";
			char key = getch();
			if (key == 'q')
			{

				for (d = drops.begin(); d != drops.end(); d++)
				{
					if (d->getX() == 0)
					{
						line.get_score(d->getX(), d->getY());
						d->erase();
						d = drops.erase(d);
						drop--;
						break;
					}
				}
			}
			else if (key == 'w')
			{

				for (d = drops.begin(); d != drops.end(); d++)
				{
					if (d->getX() == 5)
					{
						line.get_score(d->getX(), d->getY());
						d->erase();
						d = drops.erase(d);
						drop--;
						break;
					}
				}
			}
			else if (key == 'e')
			{

				for (d = drops.begin(); d != drops.end(); d++)
				{
					if (d->getX() == 10)
					{
						line.get_score(d->getX(), d->getY());
						d->erase();
						d = drops.erase(d);
						drop--;
						break;
					}
				}
			}
			else if (key == 'r')
			{

				for (d = drops.begin(); d != drops.end(); d++)
				{
					if (d->getX() == 15.0)
					{
						line.get_score(d->getX(), d->getY());
						d->erase();
						d = drops.erase(d);
						drop--;
						break;
					}
				}
			}
			gotoxy(30, 10); cout << "Score : " << line.getscore();
		}
	}
	mciSendString(TEXT("stop mysong"), NULL, 0, NULL);
	mciSendString(TEXT("close mysong"), NULL, 0, NULL);

}

double record_time() {
	double s = difftime(t, start);
	int m = 0;
	gotoxy(30, 20);
	cout << "                                                  "
		<< setfill('0') << setw(2) << m << ":" << setw(2) << s;
	return s;
}
